<?php defined('BASEPATH') OR exit('No direct script access allowed');?>
<div class="container" style="margin-top: 60px;">
<?php
echo '<h1>'.$title.'</h1>';
echo $content;
?>
</div>
