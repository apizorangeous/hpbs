<?php defined('BASEPATH') OR exit('No direct script access allowed');?>
<footer>
    
</footer>
<script src="<?php echo site_url('assets/admin/js/bootstrap.min.js');?>"></script>
<?php echo $before_body;?>
</body>
</html>