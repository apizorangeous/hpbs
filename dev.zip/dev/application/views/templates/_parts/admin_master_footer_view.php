<?php defined('BASEPATH') OR exit('No direct script access allowed');?>
<footer>
    <div class="container">
       
    </div>
</footer>
<script src="<?php echo site_url('assets/admin/js/bootstrap.min.js');?>"></script>
<script src="<?php echo site_url('assets/admin/js/bootstrap-datetimepicker.min.js');?>"></script>
<script type="text/javascript">
    $(function () {
        $('.datetimepicker').datetimepicker({
            locale: 'en',
            format: 'YYYY-MM-DD HH:mm:ss',
            useCurrent: true,
            sideBySide: true,
            showTodayButton: true
        });
    });
</script>

<?php echo $before_body;?>
</body>
</html>