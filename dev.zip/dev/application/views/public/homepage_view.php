<?php defined('BASEPATH') OR exit('No direct script access allowed');?>
<div class="container" style="margin-top: 60px;">

<div class="container" align="center">
<table border='0' align='center'>
<tr>
<td colspan='3' align="center">
<h3>SILA KLIK PAUTAN DI BAWAH UNTUK KOMUNIKASI YANG LEBIH CEPAT DAN PANTAS</h3><br />
<small>PLEASE CLICK THE ICONS BELOW FOR A FASTER AND SPEEDY COMMUNICATION</small>
</td>
</tr>
</table>
</div>
<br /><br />
<div class="container" align="center">
<table border='0'>
<tr>
<td width='250' align="center"><a href="views/application1"><img src="https://s28.postimg.org/94lz9q1ix/Forms.png"></a></td>
<td width='250' align="center"><img src="https://s28.postimg.org/l3xhh173t/Card.png"></td>
<td width='250' align="center"><img src="https://s28.postimg.org/nmj6hpsu1/Certificate.png"></td>
</tr>
<tr>
<td width='250' align="center">PERMOHONAN PENGIKTIRAFAN TENAGA PENGAJAR</td>
<td width='250' align="center">PERMOHONAN PENGIKTIRAFAN PENYEDIAAN LATIHAN</td>
<td width='250' align="center">PERMOHONAN PENGIKTIRAFAN PROFESIONAL HALAL</td>
</tr>
</table>


</div>

</div>
