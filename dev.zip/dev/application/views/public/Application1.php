<?php defined('BASEPATH') OR exit('No direct script access allowed');?>
<div class="container" style="margin-top: 60px;">

<div class="page-header"><h2>Permohonan Pengiktirafan Tenaga Pengajar</h2></div>

<div class="row">

	<div class="col-md-6">
		<div class="box box-primary">
			<div class="box-header">
				<h3 class="box-title">Maklumat Pemohon</h3>
			</div>

			<div class="form-group">
    		<label for="inputlg">Nama Pemohon</label>
    		<input class="form-control" id="inputdefault" type="text">
  			</div>

  			<div class="form-group">
    		<label for="inputlg">No. Kad Pengenalan</label>
    		<input class="form-control" id="inputdefault" type="text">
  			</div>

  			<div class="form-group">
    		<label for="inputlg">No. Kad Pengenalan</label>
    		<input class="form-control" id="inputdefault" type="text">
  			</div>

  			<div class="form-group">
    		<label for="inputlg">Alamat Rumah</label>
    		<input class="form-control" id="inputdefault" type="text">
  			</div>

  			<div class="form-group">
    		<label for="inputlg">Pekerjaan Sekarang</label>
    		<input class="form-control" id="inputdefault" type="text">
  			</div>

  			<div class="form-group">
    		<label for="inputlg">Nama Majikan</label>
    		<input class="form-control" id="inputdefault" type="text">
  			</div>

  			<div class="form-group">
    		<label for="inputlg">Alamat Majikan</label>
    		<input class="form-control" id="inputdefault" type="text">
  			</div>

  			<div class="form-group">
    		<label for="inputlg">No. Telefon Bimbit</label>
    		<input class="form-control" id="inputdefault" type="text">
  			</div>

  			<div class="form-group">
    		<label for="inputlg">No. Telefon Pejabat</label>
    		<input class="form-control" id="inputdefault" type="text">
  			</div>

  			<div class="form-group">
    		<label for="inputlg">No. Fax Pejabat</label>
    		<input class="form-control" id="inputdefault" type="text">
  			</div>

  			<div class="form-group">
    		<label for="inputlg">Alamat Email</label>
    		<input class="form-control" id="inputdefault" type="text">
  			</div>

  			<div class="form-group">
    		<label for="inputlg">Tarikh Hadir KWTP</label>
    		<!-- DateTimePicker-->
    		<input class="form-control" id="inputdefault" type="text">
  			</div>

  			<div class="form-group">
    		<label for="inputlg">No. Siri Sijil</label>
    		<input class="form-control" id="inputdefault" type="text">
  			</div>

  			<div class="form-group"> 
    <label for="inputlg">Nama Program Dipohon:</label><br />
      <div class="checkbox">
        <label><input type="checkbox"> Eksekutif Halal</label><br />
        <label><input type="checkbox"> Juru Audit Halal Dalaman</label>
    </div>
  </div>


  <div class="form-group">
      <button type="button" class="btn btn-primary btn-lg">Hantar</button>
        <button type="button" class="btn btn-default btn-lg">Batal</button>

  </div>
		</div>
	</div>
</div>

</div>