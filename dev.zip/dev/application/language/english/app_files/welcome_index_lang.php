<?php defined('BASEPATH') OR exit('No direct script access allowed');

$lang['homepage_welcome'] = 'Welcome to our website. We sure hope you will like what you will find in here.';