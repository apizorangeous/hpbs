<?php defined('BASEPATH') OR exit('No direct script access allowed');
$lang['homepage_welcome'] = 'Bienvenido a tu sitio web. Estamos seguros que te gustar&aacute; lo que encontraras aqu&iacute;.';
