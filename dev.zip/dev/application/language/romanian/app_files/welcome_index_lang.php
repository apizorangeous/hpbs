<?php defined('BASEPATH') OR exit('No direct script access allowed');

$lang['homepage_welcome'] = 'Bine ai venit pe acest site. Sper sa gasesti ce cauti aici...';