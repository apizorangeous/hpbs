<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Contents extends Admin_Controller
{

	function __construct()
	{
		parent::__construct();
        if(!$this->ion_auth->in_group('admin'))
        {
            $this->postal->add('You are not allowed to visit the Contents page','error');
            redirect('admin','refresh');
        }
        $this->load->model('content_model');
        $this->load->model('content_translation_model');
        $this->load->model('slug_model');
        $this->load->model('language_model');
        $this->load->library('form_validation');
        $this->load->helper('text');
	}

	public function index($content_type = 'page')
	{
        $list_content = $this->content_model->get_content_list($content_type);
        $this->data['content_type'] = $content_type;
        $this->data['contents'] = $list_content;
        $this->render('admin/contents/index_view');
	}

   
}