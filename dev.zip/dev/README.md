# CodeIgniter-multilanguage-site
A multi-language site created in CodeIgniter 3


Go to yoursite/admin, login with username: "administrator" and password: "password".

This is not a final product. Take care. If you have issues to report, I would be more than happy to find a solutions. If you don't understand something, you can write me at avenir.ro[@]gmail(.)com
