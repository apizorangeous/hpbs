<?php defined('BASEPATH') OR exit('No direct script access allowed');?>
<div class="container" style="margin-top:60px;">
    <div class="row">
        <h3>Senarai Permohonan Pengiktirafan Tenaga Pengajar</h3>
    </div>
    <div class="row">
        <div class="col-lg-12" style="margin-top: 10px;">
            <?php
            echo '<table class="table table-hover table-bordered table-condensed">';
            echo '<thead>';
            echo '<tr>';
            echo '<th>No.</th>';
            echo '<th>IC Number</th>';
            echo '<th>'.ucfirst($content_type).' Applicant Name</th>';
            echo '<th>Email Address</th>';
            echo '<th>No Telefon</th>';
            echo '<th>No Status</th>';
            echo '</tr>';
            echo '</thead>';
            echo '<tbody>';
           
            echo '</tbody>';
            echo '</table>';
            ?>
        </div>
    </div>
</div>

<!-- Next to display all the data in the table -->