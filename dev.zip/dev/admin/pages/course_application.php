<!DOCTYPE html>
<?php
session_start();

if(!isset($_SESSION['user_name'])){
	header("location: login.php");
	}
else {
	?>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Permohonan Kursus Wajib</title>
    <link href="../bower_components/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="../bower_components/metisMenu/dist/metisMenu.min.css" rel="stylesheet">
    <link href="../dist/css/timeline.css" rel="stylesheet">
    <link href="../dist/css/sb-admin-2.css" rel="stylesheet">
    <link href="../bower_components/morrisjs/morris.css" rel="stylesheet">
    <link href="../bower_components/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

</head>

<body>

    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.php"> </a>
            </div>
            <!-- /.navbar-header -->

            <ul class="nav navbar-top-links navbar-right">
                <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                        <i class="fa fa-user fa-fw"></i>  <i class="fa fa-caret-down"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-user">
                        
                        <li><a href="logout.php"><i class="fa fa-sign-out fa-fw"></i> Logout</a>
                        </li>
                    </ul>
                    <!-- /.dropdown-user -->
                </li>
                <!-- /.dropdown -->
            </ul>
            <!-- /.navbar-top-links -->

            <div class="navbar-default sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">
                    
                </div>
                <!-- /.sidebar-collapse -->
            </div>
            <!-- /.navbar-static-side -->
        </nav>

        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                  <h1 class="page-header">  <span class="fa fa-edit"></span>Permohonan Baru</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
			
			 <div class="col-lg-6">
                <form role="form" action="" method="POST" enctype="multipart/form-data">
                                        <div class="form-group">
                                            <label>Nama Pemohon</label>
                                            <input class="form-control" name="title">
                                        </div>
                                  
                                        <div class="form-group">
                                            <label>No Kad Pengenalan</label>
                                             <input class="form-control" name="title">
                                        </div>

                                        <div class="form-group">
                                            <label>Alamat Rumah</label>
                                            <textarea class="form-control" rows="4" name="desc"></textarea>
                                        </div>

                                        <div class="form-group">
                                            <label>Pekerjaan Sekarang</label>
                                             <input class="form-control" name="title">
                                        </div>

                                        <div class="form-group">
                                            <label>Nama Majikan</label>
                                             <input class="form-control" name="title">
                                        </div>

                                        <div class="form-group">
                                            <label>Alamat Majikan</label>
                                            <textarea class="form-control" rows="4" name="desc"></textarea>
                                        </div>

                                        <div class="form-group">
                                            <label>No. Telefon Bimbit</label>
                                             <input class="form-control" name="title">
                                        </div>

                                        <div class="form-group">
                                            <label>No Telefon Pejabat</label>
                                             <input class="form-control" name="title">
                                        </div>

                                        <div class="form-group">
                                            <label>No Fax</label>
                                             <input class="form-control" name="title">
                                        </div>

                                        <div class="form-group">
                                            <label>Emel</label>
                                             <input class="form-control" name="title">
                                        </div>

                                        <div class="form-group">
                                            <label>No Kelayakan Akademik Tertinggi</label>
                                             <input class="form-control" name="title">
                                        </div>

                                        <div class="form-group">
                                            <label>Pengalaman Industri</label>
                                             <input class="form-control" name="title">
                                        </div>

                                        <div class="form-group">
                                            <label>Dokumen Tambahan</label><br />
                                            <table border='1' width="600">
                                                <tr>
                                                <td colspan='2' width="250">Dokumen</td>
                                                </tr>
                                                <tr>
                                                <td>Salinan Kad Pengenalan Pemohon</td>
                                                <td width="20"><input type="file"></td>
                                                </tr>
                                                
                                                <tr>
                                                <td>Salinan Sijil Akademik Tertinggi</td>
                                                <td><input type="file"></td>
                                                </tr>

                                                <tr>
                                                <td>Resume</td>
                                                <td><input type="file"></td>
                                                </tr>
                                            </table>
                                        </div>
                                        
                                        <div class="form-group">
                                            <label>Pengakuan Pemohon</label><br />
                                            <small> 
                                                Dengan ini, saya mengaku bahawa maklumat yang diberikan di atas adalah benar dan sekiranya maklumat tersebut didapati tidak benar, maka permohonan saya batal SERTA-MERTA. Saya juga berjanji akan mematuhi terma dan syarat kursus wajib tenaga pengajar yang ditetapkan oleh Majlis Profesional Halal.
                                            </small><br /><br />
                                            <input type="checkbox" name="agreement" value="Yes" /> Saya Terima
                                            </font>
                                        </div><br />
										 <button type="submit" class="btn btn-primary" name="submit">Submit Button</button>
										</form>
                        </div>
                        </div>
                        
                 <div class="col-lg-12">
                  <h1 class="page-footer"></span></h1>
                </div>
                   
             
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="../bower_components/jquery/dist/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../bower_components/bootstrap/dist/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="../bower_components/metisMenu/dist/metisMenu.min.js"></script>

    <!-- Morris Charts JavaScript -->
    <script src="../bower_components/raphael/raphael-min.js"></script>
    <script src="../bower_components/morrisjs/morris.min.js"></script>
    <script src="../js/morris-data.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="../dist/js/sb-admin-2.js"></script>

</body>

</html>

<?php 

include('../includes/db.php');


if(isset($_POST['submit'])){


	$title = $_POST['title'];
	$desc = $_POST['desc'];

	
	if($title=='' or $desc==''){
	echo "<script>alert('Any field is empty')</script>";
	
	}
	
	
	
	$query = "insert into course(title,description) 
			values('$title','$desc')";
	
	if(mysql_query($query)){
	
	echo "<script>alert('Published')</script>";
	
	}
	
	}
}
?>


